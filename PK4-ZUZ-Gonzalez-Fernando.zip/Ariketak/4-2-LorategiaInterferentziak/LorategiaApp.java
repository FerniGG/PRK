public class LorategiaApp {
	public final static int MAX = 6;

	public static void main(String args[]) {
		Pantaila p=new Pantaila();
		p.margotu("LORATEGIA: return sakatu hasteko\n");
		try {
			int c = System.in.read();
		} catch (Exception ex) {
		}
		p.margotu("Aurre \t\tAtze \t\tGuztira\n");
		Kontagailua k = new Kontagailua(p);
		Simulatu s = new Simulatu();
		Atea aurrekoa = new Atea("", k, s,p);
		Atea atzekoa = new Atea("\t\t", k, s,p);
		aurrekoa.start();
		atzekoa.start();
	}
}

class Atea extends Thread {
	Kontagailua kont;
	String atea;
	Simulatu s;
	Pantaila p;

	public Atea(String zeinAte, Kontagailua k, Simulatu ps,Pantaila pp) {
		kont = k;
		p=pp;
		atea = zeinAte;
		s = ps;
	}

	public void run() {
		try {
			for (int i = 1; i <= LorategiaApp.MAX; i++) {
				sleep((long) (Math.random() * 1000));
				// ausazko denbora itxaron (0 eta 1 segunduren tartean)
				p.margotu(atea);
				p.margotu("[");
				for (int j = 1; j <= i; j++) {
					p.margotu("*");
					s.HWinterrupt();
				}
				for (int k = i; k < LorategiaApp.MAX; k++) {
					p.margotu(" ");
				}
				p.margotu("]\n");
				kont.gehitu();
			}
		} catch (InterruptedException e) {
		}
	}
}

class Kontagailua {
	int balioa = 0;
	Pantaila p;

	Kontagailua(Pantaila pp) {
		p=pp;
		String kont_izarra = "[";
		for (int k = balioa; k < 2 * LorategiaApp.MAX; k++) {
			kont_izarra += " ";
		}
		kont_izarra += "]";
		p.margotu("\t\t\t\t" + kont_izarra+"\n");
	}

	void gehitu() {
		int lag;
		lag = balioa; // balioa irakurri

		balioa = lag + 1; // balioa idatzi
		p.margotu("\t\t\t\t");
		p.margotu("[");
		for (int j = 1; j <= balioa; j++) {
			p.margotu("*");
			Simulatu.HWinterrupt();
		}
		for (int k = balioa; k < 2 * LorategiaApp.MAX; k++) {
			p.margotu(" ");
		}
		p.margotu("]\n");

	}
}
class Pantaila {
	public Pantaila() {
		
	}

	public void margotu(String s){
		System.out.print(s);
		}
	
	}

class Simulatu {
	public static void HWinterrupt() {
		if (Math.random() < 0.2)
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
			}
	}
}
