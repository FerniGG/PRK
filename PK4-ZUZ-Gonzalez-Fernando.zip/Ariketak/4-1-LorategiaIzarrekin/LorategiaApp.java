public class LorategiaApp {
	public final static int MAX = 6;

	public static void main(String args[]) {
		Pantaila p=new Pantaila();
		p.margotu("LORATEGIA: return sakatu hasteko\n");
		try {
			int c = System.in.read();
		} catch (Exception ex) {
		}
		p.margotu("Aurre \t\tAtze \t\tGuztira\n");
		Kontagailua k = new Kontagailua(p);
		Atea aurrekoa = new Atea("", k,p);
		Atea atzekoa = new Atea("\t\t", k,p);
		aurrekoa.start();
		atzekoa.start();
	}
}

class Atea extends Thread {
	Kontagailua kont;
	String atea;
	Pantaila p;

	public Atea(String zeinAte, Kontagailua k,Pantaila pp) {
		kont = k;
		atea = zeinAte;
		p=pp;

	}

	public void run() {
		try {
			for (int i = 1; i <= LorategiaApp.MAX; i++) {
				sleep((long) (Math.random() * 1000));
				// ausazko denbora itxaron (0 eta 1 segunduren tartean)
				p.margotu(atea);
				p.margotu("[");
				for (int j = 1; j <= i; j++) {
					p.margotu("*");
				}
				for (int k = i; k < LorategiaApp.MAX; k++) {
					p.margotu(" ");
				}
				p.margotu("]\n");
				kont.gehitu();
			}
		} catch (InterruptedException e) {
		}
	}
}

class Kontagailua {
	int balioa = 0;
	Pantaila p;

	Kontagailua(Pantaila pp) {
		p=pp;
		String kont_izarra = "[";
		for (int k = balioa; k < 2 * LorategiaApp.MAX; k++) {
			kont_izarra += " ";
		}
		kont_izarra += "]";
		p.margotu("\t\t\t\t" + kont_izarra+"\r\n");
	}

	void gehitu() {
		int lag;
		lag = balioa; // balioa irakurri

		balioa = lag + 1; // balioa idatzi
		p.margotu("\t\t\t\t");
		p.margotu("[");
		for (int j = 1; j <= balioa; j++) {
			p.margotu("*");
		}
		for (int k = balioa; k < 2 * LorategiaApp.MAX; k++) {
			p.margotu(" ");
		}
		p.margotu("]\r\n");

	}
}
class Pantaila {
	public Pantaila() {
		
	}

	public void margotu(String s){
		System.out.print(s);
		}
	
		}

