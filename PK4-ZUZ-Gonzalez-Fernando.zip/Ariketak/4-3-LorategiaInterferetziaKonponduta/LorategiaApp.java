public class LorategiaApp {
	public final static int MAX = 6;

	public static void main(String args[]) {
		Pantaila p=new Pantaila();
		p.margotuEOL("LORATEGIA: return sakatu hasteko");
		try {
			int c = System.in.read();
		} catch (Exception ex) {
		}
		p.margotuEOL("Aurre \t\tAtze \t\tGuztira");
		Simulatu s = new Simulatu();
		Kontagailua k = new Kontagailua(s,p);

		Atea aurrekoa = new Atea("", k, s);
		Atea atzekoa = new Atea("\t\t", k, s);
		aurrekoa.start();
		atzekoa.start();
	}
}

class Atea extends Thread {
	Kontagailua kont;
	String atea;
	Simulatu s;

	public Atea(String zeinAte, Kontagailua k, Simulatu ps) {
		kont = k;
		atea = zeinAte;
		s = ps;
	}

	public void run() {
		try {

			for (int i = 1; i <= LorategiaApp.MAX; i++) {
				// ausazko denbora itxaron (0 eta 1 segunduren tartean)
				kont.gehitu(atea, i);
				sleep((long) (Math.random() * 1000));
			}
		} catch (InterruptedException e) {
		}
	}
}

class Kontagailua {
	int balioa = 0;
	Simulatu s;
	Pantaila p;

	Kontagailua(Simulatu ps,Pantaila pp) {
		p=pp;
		s = ps;
		String kont_izarra = "[";
		for (int k = balioa; k < 2 * LorategiaApp.MAX; k++) {
			kont_izarra += " ";
		}
		kont_izarra += "]";
		p.margotuEOL("\t\t\t\t" + kont_izarra);
	}

	synchronized void gehitu(String atea, int i) {
		p.margotu(atea);
		p.margotu("[");
		for (int j = 1; j <= i; j++) {
			p.margotu("*");
			s.HWinterrupt();
		}
		for (int k = i; k < LorategiaApp.MAX; k++) {
			p.margotu(" ");
		}
		p.margotuEOL("]");
		int lag;
		lag = balioa; // balioa irakurri

		balioa = lag + 1; // balioa idatzi
		p.margotu("\t\t\t\t");
		p.margotu("[");
		for (int j = 1; j <= balioa; j++) {
			p.margotu("*");
			Simulatu.HWinterrupt();
		}
		for (int k = balioa; k < 2 * LorategiaApp.MAX; k++) {
			p.margotu(" ");
		}
		p.margotuEOL("]");

	}
}
class Pantaila {
	public Pantaila() {
		
	}

	public void margotu(String s){
		System.out.print(s);
		}
	public void margotuEOL(String s){
		System.out.println(s);
		}
	
	}

class Simulatu {
	public static void HWinterrupt() {
		if (Math.random() < 0.2)
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
			}
	}
}

