
public class FiloApp {
	public final static int N = 5;

	public static void main(String args[]) {
		Pantaila pant = new Pantaila(N);
		Maiordomoa m = new Maiordomoa(N, pant);
		Sardeska sar[] = new Sardeska[N];
		Filosofoa fil[] = new Filosofoa[N];
		for (int i = 0; i < N; ++i)
			sar[i] = new Sardeska(i, pant);

		for (int i = 0; i < N; ++i) {
			fil[i] = new Filosofoa(i, sar[(i - 1 + N) % N], sar[i], m, pant);
			fil[i].start();
		}
	}
}

class Maiordomoa extends Thread {
	Pantaila pant;
	int filoKop;
	int id;

	public Maiordomoa(int pid, Pantaila pp) {
		id = pid;
		filoKop = 0;
		pant = pp;
	}

	public synchronized int eseri(int zenb) throws InterruptedException {
		while (!(this.filoKop < (FiloApp.N - 1)))
			wait();
		filoKop++;
		pant.idatzi(FiloApp.N, zenb+" esertzen utzi= "+filoKop);
		notify();
		return filoKop;
	}

	public synchronized int altxatu(int zenb) throws InterruptedException {
		while (!(this.filoKop > 0))
			wait();
		filoKop--;
		pant.idatzi(FiloApp.N, zenb+" altxatzen utzi= "+filoKop);
		notify();
		return filoKop;
	}
}

class Filosofoa extends Thread {
	Maiordomoa maior;
	Pantaila pant;
	String space;
	int zenb;
	Sardeska eskubikoa;
	Sardeska ezkerrekoa;

	public Filosofoa(int pzenb, Sardeska ezk, Sardeska esk, Maiordomoa m, Pantaila pp) {
		maior = m;
		zenb = pzenb;
		for (int i = 1; i <= zenb + 1; i++) {
			space += "\t\t";
		}
		pant = pp;
		eskubikoa = esk;
		ezkerrekoa = ezk;
	}

	public void run() {
		try {
			int zenbateserita = 0;
			while (true) {
				if (this.zenb % 2 == 0) {
					pant.idatzi(zenb, "pentsatzen");
					sleep(1000);
					zenbateserita = maior.eseri(this.zenb);
					if (zenbateserita < (FiloApp.N - 1)) {
						pant.idatzi(zenb, "eseri");
						sleep(200);
						eskubikoa.get();
						pant.idatzi(zenb, "eskub.hartu du");
						sleep(1000);
						ezkerrekoa.get();
						pant.idatzi(zenb, "ezker.hartu du");
						sleep(200);
						pant.idatzi(zenb, "jaten");
						sleep(1000);
						eskubikoa.put();
						pant.idatzi(zenb, "eskub.utzi du");
						sleep(1000);
						ezkerrekoa.put();
						pant.idatzi(zenb, "ezker.utzi du");
						sleep(200);
						maior.altxatu(zenb);
						pant.idatzi(zenb, "altxatu");
						sleep(1000);
					}
				} else {
					zenbateserita = maior.eseri(this.zenb);
					if (zenbateserita < (FiloApp.N - 1)) {
						pant.idatzi(zenb, "pentsatzen");
						sleep(1000);
						pant.idatzi(zenb, "eseri");
						sleep(200);
						ezkerrekoa.get();
						pant.idatzi(zenb, "ezker.hartu du");
						sleep(200);
						eskubikoa.get();
						pant.idatzi(zenb, "eskub.hartu du");
						sleep(1000);
						pant.idatzi(zenb, "jaten");
						sleep(1000);
						ezkerrekoa.put();
						pant.idatzi(zenb, "ezker.utzi du");
						sleep(200);
						eskubikoa.put();
						pant.idatzi(zenb, "eskub.utzi du");
						sleep(1000);
						maior.altxatu(zenb);
						pant.idatzi(zenb, "altxatu");
						sleep(1000);
					}
				}
			}
		} catch (InterruptedException e) {
		}
	}
}

class Sardeska {
	private boolean hartua = false;
	private int zenbakia;
	private Pantaila pant;

	Sardeska(int zenb, Pantaila p) {
		zenbakia = zenb;
		pant = p;
	}

	public synchronized void put() {
		hartua = false;
		pant.idatzi(zenbakia + " utzia ");
		notify();
	}

	// when (h==0) get->SARD[1]
	public synchronized void get() throws java.lang.InterruptedException {
		while (hartua)
			wait();
		hartua = true;
		pant.idatzi(zenbakia + " hartua");
	}
}

class Pantaila {
	int kop;

	public Pantaila(int k) {
		kop = k;
		System.out.print("Sardeak\t|\t");
		for (int i = 0; i < kop; ++i)
			System.out.print("Fil[" + i + "]\t\t");
		System.out.println("Maior");
		System.out.print("========|========");
		for (int i = 0; i < kop; ++i)
			System.out.print("================");
		System.out.println("========|========");
	}

	public synchronized void idatzi(int nor, String testua) {
		System.out.print("\t|\t");
		for (int i = 0; i <= kop; i++) {
			if (nor == i)
				System.out.print(testua);
			else
				System.out.print("\t\t");
		}
		System.out.println();
	}

	public synchronized void idatzi(String testua) {
		System.out.println(testua + "|");
	}

}

