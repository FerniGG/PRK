
public class RotondaApp {
	public final static int N = 4;

	public static void main(String args[]) {
		Pantaila pant = new Pantaila(N);
		Udaltzaina u = new Udaltzaina(N, pant);
		Bidea bide[] = new Bidea[N];
		Kotxea k[] = new Kotxea[N];
		for (int i = 0; i < N; ++i)
			bide[i] = new Bidea(i,u,pant);

		for (int i = 0; i < N; ++i) {
			k[i] = new Kotxea(i,  bide[i],bide[(i + 1 + N) % N], u, pant);
			k[i].start();
		}
	}
}

class Udaltzaina extends Thread {
	Pantaila pant;
	int[] bideak = new int[RotondaApp.N];
	int kotxeKop;
	int id;

	public Udaltzaina(int pid, Pantaila pp) {
		id = pid;
		kotxeKop = 0;
		pant = pp;
	}

	public synchronized void gelditu(int zenb) throws InterruptedException {
		while (!(this.kotxeKop < (RotondaApp.N - 1)))
			wait();
		kotxeKop++;
		bideak[zenb] = 1;
		pant.idatziGurutzea(bideak, kotxeKop);
		notify();
	}

	public synchronized void jarraitu(int zenb) throws InterruptedException {
		while (!(this.kotxeKop > 0))
			wait();
		kotxeKop--;
		bideak[zenb] = 0;
		pant.idatziGurutzea(bideak, kotxeKop);
		notify();
	}
}

class Kotxea extends Thread {
	Udaltzaina udal;
	Pantaila pant;
	String space;
	int zenb;
	Bidea eskBidea;
	Bidea unekoBidea;

	public Kotxea(int pzenb, Bidea uneko, Bidea esk, Udaltzaina m, Pantaila pp) {
		udal = m;
		zenb = pzenb;
		for (int i = 1; i <= zenb + 1; i++) {
			space += "\t\t";
		}
		pant = pp;
		eskBidea = esk;
		unekoBidea = uneko;
	}

	public void run() {
		try {
			while (true) {
				sleep(1000);
				udal.gelditu(this.zenb);
				pant.idatzi(zenb, "gelditu");
				sleep(200);
				unekoBidea.okupatu();
				pant.idatzi(zenb, "uneko okup");
				sleep(200);
				eskBidea.okupatu();
				pant.idatzi(zenb, "esk okup");
				sleep(1000);
				pant.idatzi(zenb, "martxan " + zenb + "->" + (zenb + 1 + RotondaApp.N) % RotondaApp.N);
				sleep(1000);
				unekoBidea.libratu();
				pant.idatzi(zenb, "uneko libre");
				sleep(1000);
				eskBidea.libratu();
				pant.idatzi(zenb, "esk libre");
				sleep(200);
				udal.jarraitu(zenb);
				pant.idatzi(zenb, "atera");
				sleep(1000);

			}
		} catch (InterruptedException e) {
		}
	}
}

class Bidea {
	private boolean okup = false;
	private int zenbakia;
	private Pantaila pant;
	private Udaltzaina udal;

	Bidea(int zenb,Udaltzaina pudal, Pantaila p) {
		zenbakia = zenb;
		pant = p;
		udal=pudal;
	}

	// when (h==1) okupatu->BIDEA[0]
	public synchronized void libratu() {
		okup = false;
		pant.idatzi(zenbakia + " libre ");
		notify();
	}

	// when (h==0) okupatu->BIDEA[1]
	public synchronized void okupatu() throws java.lang.InterruptedException {
		while (okup)
			wait();
		okup = true;
		pant.idatzi(zenbakia + " okup  ");
		notify();
	}
}

class Pantaila {
	int kop;

	public Pantaila(int k) {
		kop = k;
		System.out.print("Bideak\t|\t");
		for (int i = 0; i < kop; ++i)
			System.out.print("K[" + i + "]\t\t");
		System.out.println("Udaltzaina");
		this.hasieratuGurutzea();
		System.out.print("========|========");
		for (int i = 0; i < kop; ++i)
			System.out.print("================");
		System.out.println("========|========");
		
	}

	public synchronized void idatzi(int nor, String testua) {
		System.out.print("\t|\t");
		for (int i = 0; i <= kop; i++) {
			if (nor == i)
				System.out.print(testua);
			else
				System.out.print("\t\t");
		}
		System.out.println();
	}

	public synchronized void idatzi(String testua) {
		System.out.println(testua + "|");
	}

	public synchronized void idatziGurutzea(int[] eser, int kop) {
		String gurutzea = "[";
		for (int i = 0; i < RotondaApp.N-1; i++) {
			if (eser[i] == 1) {
				gurutzea += "*,";
			} else {
				gurutzea += "_,";
			}
		}
		if (eser[RotondaApp.N-1] == 1) {
			gurutzea += "*";
		} else {
			gurutzea += "_";
		}
		gurutzea += "]  Kop=" + kop;
		this.idatzi(RotondaApp.N, gurutzea);
	}

	public synchronized void hasieratuGurutzea() {
		String gurutzea ="[0";
		for (int i = 1; i < RotondaApp.N; i++) {
			gurutzea += ","+i;
		}
		gurutzea += "]";
		this.idatzi(RotondaApp.N, gurutzea);
	}

}

